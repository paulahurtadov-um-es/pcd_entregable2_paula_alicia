#producer.py
from kafka import KafkaProducer
import time
import json
import pandas as pd
import sys
import random

class Sensor:
    def __init__(self):
        self.data = 0

    def set_data(self):
        t = random.randrange(0, 50)
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        self.data = [timestamp, t]


class Producer:
    def __init__(self, topic, freq):
        self.topic = topic
        self.freq = freq if isinstance(freq, int) else int(freq)  #freq es la frecuencia con la que se envían (producen) los mensajes, que es 5 seg en nuestro caso
        self.producer = KafkaProducer(bootstrap_servers='localhost:9092',
                                      value_serializer=lambda x: json.dumps(x).encode('utf-8'))

        self.sensor = Sensor()
        self.num_messages = 0

    def start_write(self):
        while True:
            self.num_messages+=1
            self.sensor.set_data()
            value = self.sensor.data
            self.producer.send(self.topic, value=value)
            print(f'Message {self.num_messages}: {value}')
            time.sleep(self.freq)


if __name__ == '__main__':
    producer = Producer(sys.argv[1], sys.argv[2])  #sys.argv[2] indica la frecuencia
    producer.start_write()
